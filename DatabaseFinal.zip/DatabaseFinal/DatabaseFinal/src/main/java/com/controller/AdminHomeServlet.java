package com.controller;

import com.util.Helper;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AdminHomeServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

	@Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	
    	String action = request.getParameter("action");
    	
		if (action != null && action.equals("bad_clients")) {
			request.setAttribute("viewFile", "reportbadclients.jsp");
			request.setAttribute("pageTitle", "List of clients that cuts the most number of trees");
			request.setAttribute("badClientsList", Helper.adminHomeRepository().getBadClients());
			Helper.view(request, response);
			
		}else if (action != null && action.equals("easy_clients")) {
			request.setAttribute("viewFile", "reporteasyclients.jsp");
			request.setAttribute("pageTitle", "List the clients who simply accept David Smith’s initial quotes without further\n"
					+ "negotiations");
			request.setAttribute("goodClientsList", Helper.adminHomeRepository().getEasyClients());
			Helper.view(request, response);
		}else if (action != null && action.equals("one_tree_quotes")) {
			request.setAttribute("viewFile", "reportonetreequoteclients.jsp");
			request.setAttribute("pageTitle", "List all the AGREED quotes that only involved one tree");
			request.setAttribute("oneTreeQuotesClientsList", Helper.adminHomeRepository().getOneTreeQuoteClients());
			Helper.view(request, response);
		}else if (action != null && action.equals("perspective_clients")) {
			request.setAttribute("viewFile", "reportperspectiveclients.jsp");
			request.setAttribute("pageTitle", "List all the clients that submitted some quotes but never produced any orders of work.");
			request.setAttribute("perspectiveClientsList", Helper.adminHomeRepository().getPerspectiveClients());
			Helper.view(request, response);
		}else if (action != null && action.equals("highest_tree")) {
			request.setAttribute("viewFile", "reporthighesttree.jsp");
			request.setAttribute("pageTitle", "List the highest tree that David Smith ever cut");
			request.setAttribute("highestTreeList", Helper.adminHomeRepository().getHighestTree());
			Helper.view(request, response);
		}else if (action != null && action.equals("overdue_bills")) {
			request.setAttribute("viewFile", "reportoverduebills.jsp");
			request.setAttribute("pageTitle", "List all the bills that have not been paid after one week the bill is generated");
			request.setAttribute("overduebillList", Helper.adminHomeRepository().getOverDueBills());
			Helper.view(request, response);	
		}else if (action != null && action.equals("bad_clients2")) {
			request.setAttribute("viewFile", "reportbadbillclients.jsp");
			request.setAttribute("pageTitle", "List all the clients that have never paid any bill after it is due.");
			request.setAttribute("badBillClientsList", Helper.adminHomeRepository().getBadBillClients());
			Helper.view(request, response);
			
		}else if (action != null && action.equals("good_clients2")) {
			request.setAttribute("viewFile", "reportgoodbillclients.jsp");
			request.setAttribute("pageTitle", "List all the clients that have paid their bills right after the bills are generated.");
			request.setAttribute("goodBillClientsList", Helper.adminHomeRepository().getGoodBillClients());
			Helper.view(request, response);			
		}else if (action != null && action.equals("statistics")) {
			request.setAttribute("viewFile", "reportstatistics.jsp");
			request.setAttribute("pageTitle", "List the total numbers of trees, total due amount, total paid amount.");
			request.setAttribute("statisticsList", Helper.adminHomeRepository().getStatistics());
			Helper.view(request, response);	
		}else {
	        request.setAttribute("viewFile", "adminhome.jsp");
	        request.setAttribute("pageTitle", "Root Admin Home");
	        Helper.view(request, response);
		}
		
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	
    	String message = Helper.adminHomeRepository().initializeDatabase();
    	request.setAttribute("message", message);
    	request.setAttribute("viewFile", "adminhome.jsp");
        request.setAttribute("pageTitle", "Root Admin Home");
        Helper.view(request, response);
    }
}
