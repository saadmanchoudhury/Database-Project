package com.controller;

import com.model.User;
import com.util.Helper;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class AdminQuoteRequestListServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        int userid = currentUser.getId();
    	String action = request.getParameter("action");
    	if(action!= null && action.equals("reject")){
    		int quoteid = Integer.parseInt(request.getParameter("quoteid"));
    		String message = Helper.quoteRepository().rejectQuoteRequest(quoteid,userid,"Rejected By Contractor");
			request.setAttribute("message", message);
			request.setAttribute("viewFile", "adminquoterequestlist.jsp");
	        request.setAttribute("pageTitle", "Quote Request List");
	        request.setAttribute("quoteList", Helper.quoteRepository().getAllAdminQuotes(userid));
	        Helper.view(request, response);
		}else if(action!= null && action.equals("response")){
			int quoteid = Integer.parseInt(request.getParameter("quoteid"));
			request.setAttribute("viewFile", "adminquoteresponse.jsp");
	        request.setAttribute("pageTitle", "Quote Response");
	        request.setAttribute("quoteid", quoteid);
	        Helper.view(request, response);
		}else {
			request.setAttribute("viewFile", "adminquoterequestlist.jsp");
	        request.setAttribute("pageTitle", "Quote Request List");
	        request.setAttribute("quoteList", Helper.quoteRepository().getAllAdminQuotes(userid));
	        Helper.view(request, response);
		}
    	
        
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    	int quoteid = Integer.parseInt(request.getParameter("quoteid"));
        String[] parameters = {"quoteid","price","note","schedulestart","scheduleend"};
        boolean checkResult = Helper
                .checkParameters(parameters, request.getParameterMap());
        
        if (!checkResult) {
        	request.setAttribute("quoteid", quoteid);
            request.setAttribute("viewFile", "adminquoteresponse.jsp");
            request.setAttribute("message", "Please fill all field");
            Helper.view(request, response);
        } else {
        	
        	double price = Double.parseDouble(request.getParameter("price"));
        	String note = request.getParameter("note");
        	String schedulestart = request.getParameter("schedulestart");
        	String scheduleend = request.getParameter("scheduleend");
        	
            HttpSession session = request.getSession();
            User currentUser = (User) session.getAttribute("user");
            int userid = currentUser.getId();
        	
            String message = Helper.quoteRepository().adminQuoteResponse(quoteid, userid, price, schedulestart, scheduleend, note);
            
        	request.setAttribute("viewFile", "adminquoterequestlist.jsp");
        	request.setAttribute("userList", Helper.userRepository().getAll());
        	request.setAttribute("quoteList", Helper.quoteRepository().getAllAdminQuotes(userid));
            request.setAttribute("message", message);
            Helper.view(request, response);
        }
    }
}
