package com.controller;

import com.model.User;
import com.util.Helper;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class AdminBillsListServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        int contractorid = currentUser.getId();
    	String action = request.getParameter("action");
    	if(action!= null && action.equals("response")){
			int billid = Integer.parseInt(request.getParameter("billid"));
			request.setAttribute("viewFile", "adminbillresponse.jsp");
	        request.setAttribute("pageTitle", "Bills Of Work");
	        request.setAttribute("billid", billid);
	        Helper.view(request, response);
		}else {
			request.setAttribute("viewFile", "adminbillslist.jsp");
			request.setAttribute("pageTitle", "Bills Of Work List");
	        request.setAttribute("billList", Helper.billRepository().getAllAdminBillsOfWork(contractorid));
	        Helper.view(request, response);
		}
    	
        
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    	int billid = Integer.parseInt(request.getParameter("billid"));
        String[] parameters = {"billid","discount","note"};
        boolean checkResult = Helper
                .checkParameters(parameters, request.getParameterMap());
        
        if (!checkResult) {
        	request.setAttribute("billid", billid);
            request.setAttribute("viewFile", "adminbillresponse.jsp");
            request.setAttribute("message", "Please fill all field");
            Helper.view(request, response);
        } else {
        	
        	double discount = Double.parseDouble(request.getParameter("discount"));
        	String note = request.getParameter("note");
            HttpSession session = request.getSession();
            User currentUser = (User) session.getAttribute("user");
            int contractorid = currentUser.getId();
        	
            String message = Helper.billRepository().adminBillResponse(billid, contractorid, discount,  note);
            
        	request.setAttribute("viewFile", "adminbillslist.jsp");
        	request.setAttribute("billList", Helper.billRepository().getAllAdminBillsOfWork(contractorid));
        	request.setAttribute("message", message);
            Helper.view(request, response);
        }
    }
}
