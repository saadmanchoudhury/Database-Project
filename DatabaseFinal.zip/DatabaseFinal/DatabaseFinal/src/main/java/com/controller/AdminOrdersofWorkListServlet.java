package com.controller;

import com.model.User;
import com.util.Helper;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class AdminOrdersofWorkListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		User currentUser = (User) session.getAttribute("user");
		int userid = currentUser.getId();
		String action = request.getParameter("action");
		if (action != null && action.equals("genbill")) {
			int orderid = Integer.parseInt(request.getParameter("orderid"));
			String message = Helper.billRepository().generateBill(orderid, userid);
			request.setAttribute("message", message);
			request.setAttribute("viewFile", "adminordersofworklist.jsp");
			request.setAttribute("pageTitle", "Work Order List");
			request.setAttribute("orderList", Helper.billRepository().getAllAdminOrders(userid));
			Helper.view(request, response);
		} else {
			request.setAttribute("viewFile", "adminordersofworklist.jsp");
			request.setAttribute("pageTitle", "Work Order List");
			request.setAttribute("orderList", Helper.billRepository().getAllAdminOrders(userid));
			Helper.view(request, response);
		}
	}
}
