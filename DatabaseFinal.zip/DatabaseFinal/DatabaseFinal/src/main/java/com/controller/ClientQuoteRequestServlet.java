package com.controller;

import com.model.User;
import com.util.Helper;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ClientQuoteRequestServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setAttribute("viewFile", "clientquoterequest.jsp");
		request.setAttribute("pageTitle", "Quote Request");
		request.setAttribute("userList", Helper.userRepository().getAll());
		Helper.view(request, response);
		
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String[] parameters = { "contractorid","nooftrees", "size", "height", "distance", "note" };
		boolean checkResult = Helper.checkParameters(parameters, request.getParameterMap());

		if (!checkResult) {
			request.setAttribute("viewFile", "clientquoterequest.jsp");
			request.setAttribute("message", "Please fill all field");
			Helper.view(request, response);
		} else {
			int contractorid = Integer.parseInt(request.getParameter("contractorid"));
			int nooftrees = Integer.parseInt(request.getParameter("nooftrees")); 
			int size = Integer.parseInt(request.getParameter("size"));
			int height = Integer.parseInt(request.getParameter("height"));
			double distance = Double.parseDouble(request.getParameter("distance"));
			String pic1 = request.getParameter("pic1");
			String pic2 = request.getParameter("pic2");
			String pic3 = request.getParameter("pic3");
			String note = request.getParameter("note");
			HttpSession session = request.getSession();
			User currentUser = (User) session.getAttribute("user");
			int clientId = currentUser.getId();

			String message = Helper.quoteRepository().clientQuoteRequest(clientId, contractorid, nooftrees,size, height, distance,
					pic1, pic2, pic3, note);

			request.setAttribute("viewFile", "clientquoterequest.jsp");
			request.setAttribute("userList", Helper.userRepository().getAll());
			request.setAttribute("message", message);
			Helper.view(request, response);
		}
	}
}
