package com.controller;

import com.model.User;
import com.util.Helper;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ClientQuoteRequestListServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        int userid = currentUser.getId();
    	String action = request.getParameter("action");
    	if(action!= null && action.equals("reject")){
    		int quoteid = Integer.parseInt(request.getParameter("quoteid"));
    		String message = Helper.quoteRepository().rejectQuoteRequest(quoteid,userid,"Rejected By Client");
			request.setAttribute("message", message);
			request.setAttribute("viewFile", "clientquoterequestlist.jsp");
	        request.setAttribute("pageTitle", "Quote Response List");
	        request.setAttribute("quoteList", Helper.quoteRepository().getAllClientQuotes(userid));
	        Helper.view(request, response);
		}else if(action!= null && action.equals("accept")){
			int quoteid = Integer.parseInt(request.getParameter("quoteid"));
    		String message = Helper.quoteRepository().acceptQuoteRequest(quoteid,userid,"Accepted By Client");
			request.setAttribute("message", message);
			request.setAttribute("viewFile", "clientquoterequestlist.jsp");
	        request.setAttribute("pageTitle", "Quote Response List");
	        request.setAttribute("quoteList", Helper.quoteRepository().getAllClientQuotes(userid));
	        Helper.view(request, response);
		}else if(action!= null && action.equals("response")){
			int quoteid = Integer.parseInt(request.getParameter("quoteid"));
			request.setAttribute("viewFile", "clientquoteresponse.jsp");
	        request.setAttribute("pageTitle", "Quote Response");
	        request.setAttribute("quoteid", quoteid);
	        Helper.view(request, response);
		}else if(action!= null && action.equals("complete")){
			int quoteid = Integer.parseInt(request.getParameter("quoteid"));
    		String message = Helper.quoteRepository().completeQuoteRequest(quoteid,userid,"Order Completed By Client");
			request.setAttribute("message", message);
			request.setAttribute("viewFile", "clientquoterequestlist.jsp");
	        request.setAttribute("pageTitle", "Quote Response List");
	        request.setAttribute("quoteList", Helper.quoteRepository().getAllClientQuotes(userid));
	        Helper.view(request, response);
		}else {
			request.setAttribute("viewFile", "clientquoterequestlist.jsp");
	        request.setAttribute("pageTitle", "Quote Response List");
	        request.setAttribute("quoteList", Helper.quoteRepository().getAllClientQuotes(userid));
	        Helper.view(request, response);
		}
    	
        
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    	int quoteid = Integer.parseInt(request.getParameter("quoteid"));
        String[] parameters = {"quoteid","note"};
        boolean checkResult = Helper
                .checkParameters(parameters, request.getParameterMap());
        
        if (!checkResult) {
        	request.setAttribute("quoteid", quoteid);
            request.setAttribute("viewFile", "clientquoteresponse.jsp");
            request.setAttribute("message", "Please fill all field");
            Helper.view(request, response);
        } else {
        	String note = request.getParameter("note");
            HttpSession session = request.getSession();
            User currentUser = (User) session.getAttribute("user");
            int userid = currentUser.getId();
        	
            String message = Helper.quoteRepository().clientQuoteResponse(quoteid, userid, note);
            
        	request.setAttribute("viewFile", "clientquoterequestlist.jsp");
        	request.setAttribute("userList", Helper.userRepository().getAll());
        	request.setAttribute("quoteList", Helper.quoteRepository().getAllClientQuotes(userid));
            request.setAttribute("message", message);
            Helper.view(request, response);
        }
    }
}
