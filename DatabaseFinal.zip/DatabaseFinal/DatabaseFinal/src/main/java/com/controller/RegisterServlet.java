package com.controller;

import com.model.User;
import com.util.Helper;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RegisterServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setAttribute("viewFile", "register.jsp");
        request.setAttribute("pageTitle", "Register User");
        Helper.view(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String[] parameters = {"firstname", "lastname", "creditcard","email", "address","phoneno","username","password","cpassword"};
        boolean checkResult = Helper
                .checkParameters(parameters, request.getParameterMap());

        if (!checkResult) {
            request.setAttribute("viewFile", "register.jsp");
            request.setAttribute("message", "Please fill all field");
            Helper.view(request, response);
        } else {

            String fistName = request.getParameter("firstname");
            String lastName = request.getParameter("lastname");
            String creditcard = request.getParameter("creditcard");
            String email = request.getParameter("email");
            String address = request.getParameter("address");
            String phoneno = request.getParameter("phoneno");
            String role = request.getParameter("role");
            String username = request.getParameter("username");
            String password = request.getParameter("password");
            String cpassword = request.getParameter("cpassword");

            if(!password.equals(cpassword)) {
            	request.setAttribute("viewFile", "register.jsp");
                request.setAttribute("message", "Password does not match confirm password");
                Helper.view(request, response);
            }else {
	            User newUser = new User();
	            newUser.setFirstName(fistName);
	            newUser.setLastName(lastName);
	            newUser.setCreditCard(creditcard);
	            newUser.setEmail(email);
	            newUser.setAddress(address);
	            newUser.setPhoneNo(phoneno);
	            newUser.setRole(role);
	            newUser.setUserName(username);
	            newUser.setPassword(password);
                
	
	            String registerResult = Helper.userRepository().add(newUser);
	            if (registerResult.equals("Success")) {
//	                response.sendRedirect("login");
	            	request.setAttribute("message", "User Registered Successfully!");
	                request.setAttribute("viewFile", "register.jsp");
	                request.setAttribute("pageTitle", "Register User");
	                Helper.view(request, response);
	            } else {
	                request.setAttribute("message", "Something went wrong."+registerResult);
	                request.setAttribute("viewFile", "register.jsp");
	                request.setAttribute("pageTitle", "Register User");
	                Helper.view(request, response);
	            }
            }
        }
        
    }
}
