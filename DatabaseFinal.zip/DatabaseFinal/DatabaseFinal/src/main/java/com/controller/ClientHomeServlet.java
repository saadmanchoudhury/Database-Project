package com.controller;

import com.util.Helper;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ClientHomeServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setAttribute("viewFile", "clienthome.jsp");
        request.setAttribute("pageTitle", "Client Home");
        Helper.view(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	
    	String message = Helper.adminHomeRepository().initializeDatabase();
    	request.setAttribute("message", message);
    	request.setAttribute("viewFile", "clienthome.jsp");
        request.setAttribute("pageTitle", "Client Home");
        Helper.view(request, response);
    }
}
