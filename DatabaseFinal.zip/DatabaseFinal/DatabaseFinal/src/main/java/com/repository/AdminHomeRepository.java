package com.repository;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.model.Bill;
import com.model.Client;

public class AdminHomeRepository {

	private final MySQL database;

	public AdminHomeRepository(MySQL database) {
		this.database = database;
	}

	/**
	 * This method initialized the database
	 * 
	 * @return
	 */
	public String initializeDatabase() {
		String message = "";
		String query = "";
		try {
			/**
			 * Drop all tables which are created in the database
			 */
			query = "DROP TABLE IF EXISTS Trees";
			database.executeSQL(query);
			query = "DROP TABLE IF EXISTS QuotesMessages";
			database.executeSQL(query);
			query = "DROP TABLE IF EXISTS BillsMessages";
			database.executeSQL(query);
			query = "DROP TABLE IF EXISTS Bills";
			database.executeSQL(query);
			query = "DROP TABLE IF EXISTS Orders";
			database.executeSQL(query);
			query = "DROP TABLE IF EXISTS Quotes";
			database.executeSQL(query);
					
			
			
			
			query = "DROP TABLE IF EXISTS Users";
			database.executeSQL(query);
			
			/**
			 * Create tables one by one
			 */
			query = "CREATE TABLE IF NOT EXISTS users (\n" + "  id int(11) NOT NULL AUTO_INCREMENT,\n"
					+ "  firstname varchar(50) NOT NULL,\n" + "  lastname varchar(50) NOT NULL,\n"
					+ "  creditcard varchar(50) NOT NULL,\n" + "  email varchar(100) NOT NULL,\n"
					+ "  address varchar(100) NOT NULL,\n" + "  phoneno varchar(50) NOT NULL,\n"
					+ "  role varchar(50) NOT NULL,\n" + "  username varchar(50) NOT NULL,\n"
					+ "  password varchar(50) NOT NULL,\n" + "  PRIMARY KEY (id),\n" + "  UNIQUE KEY email (email)\n"
					+ ") DEFAULT CHARSET=utf8;";
			database.executeSQL(query);

			query = "CREATE TABLE Quotes(\n" + "id INTEGER NOT NULL AUTO_INCREMENT,\n" + "contractorid INTEGER,\n"
					+ "clientid INTEGER,\n" + "price DOUBLE,\n" + "schedulestart DATETIME,\n"
					+ "scheduleend DATETIME,\n" + "qstatus varchar(30),\n" + "noOfTrees INTEGER,\n"
					+ "PRIMARY KEY(id)\n"
					+ "\n" + ");";
			database.executeSQL(query);

			query = "\n" + "CREATE TABLE Trees(\n" + "id INTEGER NOT NULL AUTO_INCREMENT,\n" + "quoteid INTEGER,\n"
					+ "size DOUBLE,\n" + "height DOUBLE,\n" + "distanceFromHouse DOUBLE,\n" + "pic1 varchar(100),\n"
					+ "pic2 varchar(100), \n" + "pic3 varchar(100),\n" + "PRIMARY KEY(id))";
			database.executeSQL(query);

			query = "CREATE TABLE QuotesMessages(\n" + "id INTEGER NOT NULL AUTO_INCREMENT,\n" + "userid INTEGER, \n"
					+ "quoteid INTEGER,\n" + "msgtime DATETIME,\n" + "note varchar(200),\n" + "PRIMARY KEY(id)\n"
					+ ");";
			database.executeSQL(query);

			query = "CREATE TABLE Orders(\n" + "id INTEGER NOT NULL AUTO_INCREMENT,\n" + "quoteid INTEGER,\n"
					+ "price DOUBLE,\n" + "schedulestart DATETIME,\n" + "scheduleend DATETIME,\n" + "PRIMARY KEY(id));";
			database.executeSQL(query);

			query = "CREATE TABLE Bills(\n" + "id INTEGER NOT NULL AUTO_INCREMENT,\n" + "orderid INTEGER,\n"
					+ "price DOUBLE,\n" + "discount DOUBLE,\n" + "balance DOUBLE,\n" + "status VARCHAR(20), \n"
					+ "PRIMARY KEY(id));";
			database.executeSQL(query);

			query = "CREATE TABLE BillsMessages(\n" + "id INTEGER NOT NULL AUTO_INCREMENT,\n" + "userid INTEGER,\n"
					+ "billid INTEGER, \n" + "msgtime DATETIME,\n" + "note varchar(200),\n" + "PRIMARY KEY(id));";
			database.executeSQL(query);

			/**
			 * Insert default data into tables.
			 */
			
			query = "INSERT INTO `users` VALUES (1,'David','smith','123456','david@gmail.com','Test Address','123456','david','david','david'),(2,'Yasmin','Ahmed','123456','yasmin@gmail.com','Test Address','123456','client','yasmin','yasmin'),(3,'john','john','789456','john@gmail.com','john address','789456','client','john','john'),(4,'rameen','rameen','78964','rameen@gmail.com','Test rameen address','789654','client','rameen','rameen');\n"
					+ "";
			database.executeSQL(query);
			
			query = "INSERT INTO `quotes` VALUES (1,1,2,1000,'2023-12-10 00:00:00','2023-12-15 00:00:00','Completed',1),(2,1,2,1500,'2023-12-10 00:00:00','2023-12-16 00:00:00','Completed',1),(3,1,2,NULL,NULL,NULL,'Rejected',1),(4,1,3,200,'2023-12-10 00:00:00','2023-12-12 00:00:00','Completed',1),(5,1,3,400,'2023-12-11 00:00:00','2023-12-22 00:00:00','Completed',1),(6,1,2,NULL,NULL,NULL,'open',3),(7,1,4,250,'2023-12-24 00:00:00','2023-12-27 00:00:00','Completed',3);";
			database.executeSQL(query);
			
			query = "INSERT INTO `trees` VALUES (1,1,100,100,100,'','',''),(2,2,200,200,200,'','',''),(3,3,300,300,300,'','',''),(4,4,20,20,20,'','',''),(5,5,30,30,30,'','',''),(6,6,20,20,20,'','',''),(7,7,20,20,20,'','','');\n"
					+ "";
			database.executeSQL(query);
			
			query = "INSERT INTO `quotesmessages` VALUES (1,2,1,'2023-12-10 12:02:44','This tree has width and height of 100.'),(2,2,2,'2023-12-10 12:03:09','This tree has width and height of 200.'),(3,2,3,'2023-12-10 12:03:25','This tree has width and height of 300.'),(4,1,1,'2023-12-10 12:04:30','You have 5 days slot.'),(5,1,2,'2023-12-10 12:04:52','Please start ASAP'),(6,1,3,'2023-12-10 12:04:57','Rejected By Contractor'),(7,2,1,'2023-12-10 12:05:30','Accepted By Client'),(8,2,2,'2023-12-10 12:05:41','Please reduce price'),(9,2,1,'2023-12-10 12:05:43','Order Completed By Client'),(10,1,2,'2023-12-10 12:06:27','Price reduced to 1500'),(11,2,2,'2023-12-10 12:06:56','Accepted By Client'),(12,2,2,'2023-12-10 12:06:59','Order Completed By Client'),(13,3,4,'2023-12-10 13:03:35','Tree 1'),(14,3,5,'2023-12-10 13:03:49','Tree 2 request'),(15,1,4,'2023-12-10 13:04:25','Please start'),(16,1,5,'2023-12-10 13:04:40','ASAP'),(17,3,4,'2023-12-10 13:04:54','Accepted By Client'),(18,3,5,'2023-12-10 13:04:56','Accepted By Client'),(19,3,4,'2023-12-10 13:04:57','Order Completed By Client'),(20,3,5,'2023-12-10 13:04:57','Order Completed By Client'),(21,2,6,'2023-12-10 13:38:52','3 trees quote'),(22,4,7,'2023-12-10 13:56:20','3 trees'),(23,1,7,'2023-12-10 13:57:04','thanks. Start it'),(24,4,7,'2023-12-10 13:57:17','Accepted By Client'),(25,4,7,'2023-12-10 14:05:05','Order Completed By Client');\n"
					+ "";
			database.executeSQL(query);
			
			query = "INSERT INTO `orders` VALUES (1,1,1000,'2023-12-10 00:00:00','2023-12-15 00:00:00'),(2,2,1500,'2023-12-10 00:00:00','2023-12-16 00:00:00'),(3,4,200,'2023-12-10 00:00:00','2023-12-12 00:00:00'),(4,5,400,'2023-12-11 00:00:00','2023-12-22 00:00:00'),(5,7,250,'2023-12-24 00:00:00','2023-12-27 00:00:00');\n"
					+ "";
			database.executeSQL(query);
			
			query = "INSERT INTO `bills` VALUES (1,1,1000,0,0,'Paid'),(2,2,1500,300,0,'Paid'),(3,3,200,0,0,'Paid'),(4,4,400,0,0,'Paid'),(5,5,250,0,0,'Generated');\n"
					+ "";
			database.executeSQL(query);
			
			query = "INSERT INTO `billsmessages` VALUES (1,2,1,'2023-12-10 12:07:07','Bill Paid By Client'),(2,2,2,'2023-12-10 12:07:58','Please give discount'),(3,1,2,'2023-12-10 12:08:24','300 discount given'),(4,2,2,'2023-12-10 12:08:48','Bill Paid By Client'),(5,3,3,'2023-12-10 13:05:30','Bill Paid By Client'),(6,3,4,'2023-12-10 13:05:36','Bill Paid By Client');\n"
					+ "";
			database.executeSQL(query);
			
			message = "Database initialized successfully!";
		} catch (Exception e) {
			return e.getMessage();
		}
		return message;
	}

	/**
	 * List of clients that cuts the most number of trees
	 * 
	 * @return
	 */
	public List<Client> getBadClients() {
		List<Client> list = new ArrayList<>();

		String query = "SELECT clientid, count(clientid) as nooftreecut " + "FROM Quotes where qstatus='completed' "
				+ "GROUP BY clientid " + "ORDER BY nooftreecut desc";
		try {
			ResultSet resultSet = database.executeQuery(query);
			while (resultSet.next()) {
				Client client = new Client();
				int clientid = resultSet.getInt("clientid");
				int nooftreecut = resultSet.getInt("nooftreecut");
				client.setId(clientid);
				client.setNooftreescut(nooftreecut);

				query = "SELECT * from Users WHERE id=" + clientid;
				ResultSet resultSet2 = database.executeQuery(query);
				if (resultSet2.next()) {
					client.setFirstName(resultSet2.getString("firstname"));
					client.setLastName(resultSet2.getString("lastname"));
				}
				list.add(client);
			}
		} catch (Exception ex) {
			return list;
		}
		return list;
	}

	/**
	 * : List the clients who simply accept David Smith’s initial quotes without
	 * further negotiations
	 * 
	 * @return
	 */
	public List<Client> getEasyClients() {
		List<Client> list = new ArrayList<>();

		String query = "SELECT id, clientid " + "FROM Quotes where qstatus='Accepted' or qstatus='Completed' ";
		try {
			ResultSet resultSet = database.executeQuery(query);
			while (resultSet.next()) {
				Client client = new Client();
				int quoteid = resultSet.getInt("id");
				int clientid = resultSet.getInt("clientid");
				client.setId(clientid);
				query = "SELECT * from Users WHERE id=" + clientid;
				ResultSet resultSet2 = database.executeQuery(query);
				if (resultSet2.next()) {
					client.setFirstName(resultSet2.getString("firstname"));
					client.setLastName(resultSet2.getString("lastname"));
				}

				query = "SELECT count(*) as totalmsg FROM quotesmessages where quoteid=" + quoteid
						+ " and note !='Order Completed By Client'";
				resultSet2 = database.executeQuery(query);
				int totalmsg = 0;
				if (resultSet2.next()) {
					totalmsg = resultSet2.getInt("totalmsg");
				}

				if (totalmsg <= 3) {
					boolean alreadyAdded = false;
					for (Client c : list) {
						if (c.getFirstName().equals(client.getFirstName())) {
							alreadyAdded = true;
						}
					}
					if (!alreadyAdded)
						list.add(client);
				}
			}
		} catch (Exception ex) {
			return list;
		}
		return list;
	}

	/**
	 * List all the AGREED quotes that only involved one tree
	 * 
	 * @return
	 */
	public List<Client> getOneTreeQuoteClients() {
		List<Client> list = new ArrayList<>();

		String query = "SELECT id, clientid "
				+ "FROM Quotes where qstatus='Accepted' or qstatus='Completed' AND nooftrees=1";
		try {
			ResultSet resultSet = database.executeQuery(query);
			while (resultSet.next()) {
				Client client = new Client();
				int quoteid = resultSet.getInt("id");
				int clientid = resultSet.getInt("clientid");
				client.setId(clientid);
				query = "SELECT * from Users WHERE id=" + clientid;
				ResultSet resultSet2 = database.executeQuery(query);
				if (resultSet2.next()) {
					client.setFirstName(resultSet2.getString("firstname"));
					client.setLastName(resultSet2.getString("lastname"));
				}
				boolean alreadyAdded = false;
				for (Client c : list) {
					if (c.getFirstName().equals(client.getFirstName())) {
						alreadyAdded = true;
					}
				}
				if (!alreadyAdded)
					list.add(client);
			}
		} catch (Exception ex) {
			return list;
		}
		return list;
	}

	/**
	 * List all the clients that submitted some quotes but never produced any orders
	 * of work.
	 * 
	 * @return
	 */
	public List<Client> getPerspectiveClients() {
		List<Client> list = new ArrayList<>();

		String query = "SELECT id, clientid " + "FROM Quotes where qstatus='Accepted' ";
		try {
			ResultSet resultSet = database.executeQuery(query);
			while (resultSet.next()) {
				Client client = new Client();
				int quoteid = resultSet.getInt("id");
				int clientid = resultSet.getInt("clientid");
				client.setId(clientid);
				query = "SELECT * from Users WHERE id=" + clientid;
				ResultSet resultSet2 = database.executeQuery(query);
				if (resultSet2.next()) {
					client.setFirstName(resultSet2.getString("firstname"));
					client.setLastName(resultSet2.getString("lastname"));
				}

				query = "SELECT id FROM orders where quoteid=" + quoteid + "";
				resultSet2 = database.executeQuery(query);
				if (!resultSet2.next()) {
					boolean alreadyAdded = false;
					for (Client c : list) {
						if (c.getFirstName().equals(client.getFirstName())) {
							alreadyAdded = true;
						}
					}
					if (!alreadyAdded)
						list.add(client);
				}

			}
		} catch (Exception ex) {
			return list;
		}
		return list;
	}
	
	/**
	 * List all the clients that have never paid any bill after it is due. 
	 * 
	 * @return
	 */
	public List<Client> getBadBillClients() {
		List<Client> list = new ArrayList<>();

		String query = "SELECT id, clientid " + "FROM Quotes where qstatus='Completed' ";
		try {
			ResultSet resultSet = database.executeQuery(query);
			while (resultSet.next()) {
				Client client = new Client();
				int quoteid = resultSet.getInt("id");
				int clientid = resultSet.getInt("clientid");
				client.setId(clientid);
				query = "SELECT * from Users WHERE id=" + clientid;
				ResultSet resultSet2 = database.executeQuery(query);
				if (resultSet2.next()) {
					client.setFirstName(resultSet2.getString("firstname"));
					client.setLastName(resultSet2.getString("lastname"));
				}

				query = "SELECT id FROM orders where quoteid=" + quoteid + "";
				resultSet2 = database.executeQuery(query);
				int orderid = 0;
				if (resultSet2.next()) {
					orderid = resultSet2.getInt("id");
					if(orderid>0) {
						query = "SELECT id FROM bills where orderid=" + orderid + " and status != 'Paid'";
						resultSet2 = database.executeQuery(query);
						if (resultSet2.next()) {
							boolean alreadyAdded = false;
							for (Client c : list) {
								if (c.getFirstName().equals(client.getFirstName())) {
									alreadyAdded = true;
								}
							}
							if (!alreadyAdded)
								list.add(client);
						}
					}
				}

			}
		} catch (Exception ex) {
			return list;
		}
		return list;
	}
	
	/**
	 * List all the clients that have paid their bills right after the bills are generated.
	 * 
	 * @return
	 */
	public List<Client> getGoodBillClients() {
		List<Client> list = new ArrayList<>();

		String query = "SELECT id, clientid " + "FROM Quotes where qstatus='Completed' ";
		try {
			ResultSet resultSet = database.executeQuery(query);
			while (resultSet.next()) {
				Client client = new Client();
				int quoteid = resultSet.getInt("id");
				int clientid = resultSet.getInt("clientid");
				client.setId(clientid);
				query = "SELECT * from Users WHERE id=" + clientid;
				ResultSet resultSet2 = database.executeQuery(query);
				if (resultSet2.next()) {
					client.setFirstName(resultSet2.getString("firstname"));
					client.setLastName(resultSet2.getString("lastname"));
				}
				
				query = "SELECT id FROM orders where quoteid=" + quoteid + "";
				resultSet2 = database.executeQuery(query);
				int orderid = 0;
				if (resultSet2.next()) {
					orderid = resultSet2.getInt("id");
					if(orderid>0) {
						query = "SELECT id FROM bills where orderid=" + orderid + " AND status = 'Paid'";
						resultSet2 = database.executeQuery(query);
						if (resultSet2.next()) {

							boolean alreadyAdded = false;
							for (Client c : list) {
								if (c.getFirstName().equals(client.getFirstName())) {
									alreadyAdded = true;
								}
							}
							if (!alreadyAdded)
								list.add(client);
						}
					}
				}

			}
		} catch (Exception ex) {
			return list;
		}
		return list;
	}
	
	/**
	 * For each client, list the total numbers of trees, total due amount, total paid amount,
and the date when the work is done for each tree.
	 * 
	 * @return
	 */
	public List<Client> getStatistics() {
		List<Client> list = new ArrayList<>();

		String query = "SELECT clientid, sum(nooftrees) as nooftreecut " 
				+ "FROM Quotes where qstatus='completed' "
				+ "GROUP BY clientid " + "ORDER BY nooftreecut desc";
		try {
			ResultSet resultSet = database.executeQuery(query);
			while (resultSet.next()) {
				Client client = new Client();
				int clientid = resultSet.getInt("clientid");
				int nooftreecut = resultSet.getInt("nooftreecut");
				client.setId(clientid);
				client.setNooftreescut(nooftreecut);
				query = "SELECT * from Users WHERE id=" + clientid;
				ResultSet resultSet2 = database.executeQuery(query);
				if (resultSet2.next()) {
					client.setFirstName(resultSet2.getString("firstname"));
					client.setLastName(resultSet2.getString("lastname"));
				}
				double amountDue = 0;
				double amountPaid = 0;
				
				query = "SELECT q.id, q.price ,o.id as orderid, b.discount FROM quotes q, orders o, bills b \n"
						+ "WHERE q.clientid= "+clientid+" "
						+ "AND q.qstatus='completed' \n"
						+ "AND o.quoteid=q.id\n"
						+ "AND b.orderid=o.id\n"
						+ "AND b.status='paid';";
				resultSet2 = database.executeQuery(query);
				
				while (resultSet2.next()) {
					int quoteid = resultSet2.getInt("id");
					amountDue += resultSet2.getDouble("price");
					int orderid = resultSet2.getInt("orderid");
					amountPaid += resultSet2.getDouble("price")-resultSet2.getDouble("discount");
				}
				if(amountDue>0) {
					client.setDueamount(amountDue);
					client.setPaidamount(amountPaid);
					list.add(client);
				}
			}
		} catch (Exception ex) {
			return list;
		}
		return list;
	}
	
	/**
	 * List the highest tree that David Smith ever cut
	 * 
	 * @return
	 */
	public List<Client> getHighestTree() {
		List<Client> list = new ArrayList<>();

		String query = "SELECT clientid, count(clientid) as nooftreecut " + "FROM Quotes where qstatus='completed' "
				+ "GROUP BY clientid " + "ORDER BY nooftreecut desc";
		try {
			ResultSet resultSet = database.executeQuery(query);
			while (resultSet.next()) {
				Client client = new Client();
				int clientid = resultSet.getInt("clientid");
				int nooftreecut = resultSet.getInt("nooftreecut");
				client.setId(clientid);
				client.setNooftreescut(nooftreecut);

				query = "SELECT * from Users WHERE id=" + clientid;
				ResultSet resultSet2 = database.executeQuery(query);
				if (resultSet2.next()) {
					client.setFirstName(resultSet2.getString("firstname"));
					client.setLastName(resultSet2.getString("lastname"));
				}
				list.add(client);
			}
		} catch (Exception ex) {
			return list;
		}
		return list;
	}
	
	/**
	 * List all the bills that have not been paid after one week the bill is generated
	 * 
	 * @return
	 */
	public List<Bill> getOverDueBills() {
		List<Bill> list = new ArrayList<>();

		String query = "SELECT * from bills where status ='Generated'";
		try {
			ResultSet resultSet = database.executeQuery(query);
			while (resultSet.next()) {
				Bill bill = new Bill();
				bill.setBillid(resultSet.getInt("id"));
				bill.setOrderid(resultSet.getInt("orderid"));
				bill.setPrice(resultSet.getInt("price"));
				bill.setDiscount(resultSet.getInt("discount"));
				list.add(bill);
			}
		} catch (Exception ex) {
			return list;
		}
		return list;
	}
}
