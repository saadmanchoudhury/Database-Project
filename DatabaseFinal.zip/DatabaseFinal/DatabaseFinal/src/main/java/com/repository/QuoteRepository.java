package com.repository;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import com.model.Quote;

public class QuoteRepository {

	private final MySQL database;

	public QuoteRepository(MySQL database) {
		this.database = database;
	}
	/**
	 * Return all quotes for client
	 * @param userid
	 * @return
	 */
	public List<Quote> getAllClientQuotes(int userid) {
		List<Quote> list = new ArrayList<>();
		String query = "SELECT *, u.firstname FROM Quotes q, Users u WHERE u.id = q.clientid AND q.clientid="+userid+" "
				+ "ORDER BY q.id ASC";
		try {
			ResultSet resultSet = database.executeQuery(query);
			while (resultSet.next()) {
				Quote quote = new Quote();
				int quoteId = resultSet.getInt("id");
				quote.setId(quoteId);
				quote.setClientName(resultSet.getString("firstname"));
				quote.setContractorid(resultSet.getInt("contractorid"));
				quote.setClientid(resultSet.getInt("clientid"));
				quote.setPrice(resultSet.getDouble("price"));
				quote.setSchedulestart(resultSet.getTimestamp("schedulestart"));
				quote.setScheduleend(resultSet.getTimestamp("scheduleend"));
				quote.setQstatus(resultSet.getString("qstatus"));

				query = "Select * from Trees where quoteid=" + quoteId;
				ResultSet resultSet2 = database.executeQuery(query);
				if (resultSet2.next()) {
					quote.setSize(resultSet2.getInt("size"));
					quote.setHeight(resultSet2.getInt("height"));
					quote.setDistance(resultSet2.getDouble("distanceFromHouse"));
				}

				query = "Select * from QuotesMessages where quoteid=" + quoteId + " order by msgtime desc";
				resultSet2 = database.executeQuery(query);
				if (resultSet2.next()) {
					quote.setNote(resultSet2.getString("note"));
					quote.setMsgtime(resultSet2.getTimestamp("msgtime"));
				}

				list.add(quote);
			}
		} catch (Exception ex) {
			return list;
		}
		return list;
	}
	
	/**
	 * Client Quote Request
	 * @param clientId
	 * @param contractorId
	 * @param size
	 * @param height
	 * @param distance
	 * @param pic1
	 * @param pic2
	 * @param pic3
	 * @param note
	 * @return
	 */
	public String clientQuoteRequest(int clientId, int contractorId, int nooftrees,int size, int height, double distance, String pic1,
			String pic2, String pic3, String note) {
		String message = "";
		String query = "";
		try {
			query = "INSERT INTO Quotes (contractorid,clientid,qstatus,nooftrees)" + " VALUES(" + contractorId + "," + clientId
					+ ",'open',"+nooftrees+")";
			database.executeSQL(query);
			query = "SELECT id FROM Quotes order by id desc";
			int quoteID = -1;
			ResultSet resultSet = database.executeQuery(query);
			if (resultSet.next()) {
				quoteID = resultSet.getInt("id");
			}
			if (quoteID > 0) {
				// insert into tree
				query = "INSERT INTO Trees (quoteid,size,height,distanceFromHouse,pic1,pic2,pic3)" + " VALUES("
						+ quoteID + "," + size + "," + height + "," + distance + ",'" + pic1 + "','" + pic2 + "','"
						+ pic3 + "')";
				database.executeSQL(query);
				// insert into QuotesMessages
				query = "INSERT INTO QuotesMessages (quoteid,userid,msgtime,note)" + " VALUES(" + quoteID + ","
						+ clientId + ",now(),'" + note + "')";
				database.executeSQL(query);
			} else {
				message = "Quote request sent error";
			}
			message = "Quote request sent successfully";
		} catch (Exception e) {
			return e.getMessage();
		}
		return message;
	}
	/**
	 * Client Quote Response
	 * @param quoteId
	 * @param contractorId
	 * @param note
	 * @return
	 */
	public String clientQuoteResponse(int quoteId, int contractorId, String note) {
		String message = "";
		String query = "";
		try {
			query = "UPDATE Quotes SET " + "qstatus='Open' " + "WHERE id=" + quoteId;
			database.executeSQL(query);
			// insert into QuotesMessages
			query = "INSERT INTO QuotesMessages (quoteid,userid,msgtime,note)" + " VALUES(" + quoteId + ","
					+ contractorId + ",now(),'" + note + "')";
			database.executeSQL(query);
			message = "Quote response sent successfully";
		} catch (Exception e) {
			return e.getMessage();
		}
		return message;
	}
	/**
	 * Reject Quote request by either client or David
	 * @param quoteId
	 * @param userId
	 * @param note
	 * @return
	 */
	public String rejectQuoteRequest(int quoteId, int userId, String note) {
		String message = "";
		String query = "";
		try {
			query = "Update Quotes set qstatus='Rejected' where id=" + quoteId;
			database.executeSQL(query);

			// insert into QuotesMessages
			query = "INSERT INTO QuotesMessages (quoteid,userid,msgtime,note)" + " VALUES(" + quoteId + "," + userId
					+ ",now(),'" + note + "')";
			database.executeSQL(query);

			message = "Quote request rejected successfully";
		} catch (Exception e) {
			return e.getMessage();
		}
		return message;
	}
	/**
	 * Complete quote request by client
	 * @param quoteId
	 * @param userId
	 * @param note
	 * @return
	 */
	public String completeQuoteRequest(int quoteId, int userId, String note) {
		String message = "";
		String query = "";
		try {
			query = "Update Quotes set qstatus='Completed' where id=" + quoteId;
			database.executeSQL(query);

			// insert into QuotesMessages
			query = "INSERT INTO QuotesMessages (quoteid,userid,msgtime,note)" + " VALUES(" + quoteId + "," + userId
					+ ",now(),'" + note + "')";
			database.executeSQL(query);

			query = "SELECT * FROM Quotes q WHERE q.id=" + quoteId;
			ResultSet resultSet = database.executeQuery(query);
			double price = 0.0;
			String schedulestart = "";
			String scheduleend = "";
			if (resultSet.next()) {
				price = resultSet.getDouble("price");
				schedulestart = resultSet.getString("schedulestart");
				scheduleend = resultSet.getString("scheduleend");
			}

			// insert into Orders
			query = "INSERT INTO Orders (quoteid,price,schedulestart,scheduleend)" + " VALUES(" + quoteId + "," + price
					+ ",'" + schedulestart + "','" + scheduleend + "')";
			database.executeSQL(query);

			message = "Quote request completed successfully and Bill Order generated";
		} catch (Exception e) {
			return e.getMessage();
		}
		return message;
	}
	/**
	 * Accept Quote Request By Client
	 * @param quoteId
	 * @param userId
	 * @param note
	 * @return
	 */
	public String acceptQuoteRequest(int quoteId, int userId, String note) {
		String message = "";
		String query = "";
		try {
			query = "Update Quotes set qstatus='Accepted' where id=" + quoteId;
			database.executeSQL(query);

			// insert into QuotesMessages
			query = "INSERT INTO QuotesMessages (quoteid,userid,msgtime,note)" + " VALUES(" + quoteId + "," + userId
					+ ",now(),'" + note + "')";
			database.executeSQL(query);

			message = "Quote request accepted successfully";
		} catch (Exception e) {
			return e.getMessage();
		}
		return message;
	}
	/**
	 * Get all quotes for david/contractor
	 * @param userid
	 * @return
	 */
	public List<Quote> getAllAdminQuotes(int userid) {
		List<Quote> list = new ArrayList<>();
		String query = "SELECT *, u.firstname FROM Quotes q, Users u WHERE u.id = q.contractorid AND q.contractorid="+userid+" " 
						+ "ORDER BY q.id ASC";
		try {
			ResultSet resultSet = database.executeQuery(query);
			while (resultSet.next()) {
				Quote quote = new Quote();
				int quoteId = resultSet.getInt("id");
				quote.setId(quoteId);
				quote.setClientName(resultSet.getString("firstname"));
				quote.setContractorid(resultSet.getInt("contractorid"));
				quote.setClientid(resultSet.getInt("clientid"));
				quote.setPrice(resultSet.getDouble("price"));
				quote.setSchedulestart(resultSet.getTimestamp("schedulestart"));
				quote.setScheduleend(resultSet.getTimestamp("scheduleend"));
				quote.setQstatus(resultSet.getString("qstatus"));

				query = "Select * from Trees where quoteid=" + quoteId;
				ResultSet resultSet2 = database.executeQuery(query);
				if (resultSet2.next()) {
					quote.setSize(resultSet2.getInt("size"));
					quote.setHeight(resultSet2.getInt("height"));
					quote.setDistance(resultSet2.getDouble("distanceFromHouse"));
				}

				query = "Select * from QuotesMessages where quoteid=" + quoteId + " order by msgtime desc";
				resultSet2 = database.executeQuery(query);
				if (resultSet2.next()) {
					quote.setNote(resultSet2.getString("note"));
					quote.setMsgtime(resultSet2.getTimestamp("msgtime"));
				}

				list.add(quote);
			}
		} catch (Exception ex) {
			return list;
		}
		return list;
	}
	
	/**
	 * Quote response by admin
	 * @param quoteId
	 * @param contractorId
	 * @param price
	 * @param schedulestart
	 * @param scheduleend
	 * @param note
	 * @return
	 */
	public String adminQuoteResponse(int quoteId, int contractorId, double price, String schedulestart,
			String scheduleend, String note) {
		String message = "";
		String query = "";
		try {
			query = "UPDATE Quotes SET " + "price=" + price + ", " + "schedulestart='" + schedulestart + "', "
					+ "scheduleend='" + scheduleend + "', " + "qstatus='Responded' " + "WHERE id=" + quoteId;
			database.executeSQL(query);
			// insert into QuotesMessages
			query = "INSERT INTO QuotesMessages (quoteid,userid,msgtime,note)" + " VALUES(" + quoteId + ","
					+ contractorId + ",now(),'" + note + "')";
			database.executeSQL(query);
			message = "Quote response sent successfully";
		} catch (Exception e) {
			return e.getMessage();
		}
		return message;
	}


}
