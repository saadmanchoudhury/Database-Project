package com.repository;

import com.model.User;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class UserRepository {

    private final MySQL database;

    public UserRepository(MySQL database) {
        this.database = database;
    }


    /**
     * This method returns all users
     * @return
     */
    public List<User> getAll() {
        List<User> list = new ArrayList<>();
        String query = "SELECT * FROM Users "
                + "ORDER BY id ASC";
        try {
            ResultSet resultSet = database.executeQuery(query);
            while (resultSet.next()) {
                User user = new User();
                user.setId(resultSet.getInt("id"));
                user.setFirstName(resultSet.getString("firstname"));
                user.setLastName(resultSet.getString("lastname"));
                user.setCreditCard(resultSet.getString("creditcard"));
                user.setEmail(resultSet.getString("email"));
                user.setAddress(resultSet.getString("address"));
                user.setPhoneNo(resultSet.getString("phoneno"));
                user.setRole(resultSet.getString("role"));
                user.setUserName(resultSet.getString("username"));
                user.setPassword(resultSet.getString("password"));
                list.add(user);
            }
        } catch (Exception ex) {
            return list;
        }
        return list;
    }

    /**
     * This method add new user
     * @param user
     * @return
     */
    public String add(User user) {
        String result = "";
        String query = String.format("INSERT INTO Users"
                + " VALUES(NULL, '%s', '%s', '%s', '%s','%s', '%s', '%s', '%s', '%s')",
                user.getFirstName(),
                user.getLastName(),
                user.getCreditCard(),
                user.getEmail(),
                user.getAddress(),
                user.getPhoneNo(),
                user.getRole(),
                user.getUserName(),
                user.getPassword()
        		);
        try {
            database.executeSQL(query);
            result = "Success";
        } catch (Exception ex) {
            return ex.getMessage();
        }
        return result;
    }
    
    /**
     * This method checks and login the user
     * @param username
     * @param password
     * @return
     */
    public User login(String username, String password) {
        User user = null;
        String query = String
                .format("SELECT * FROM Users "
                        + "WHERE username = '%s' "
                        + "AND password = '%s'", username, password);
        try {
            ResultSet resultSet = database.executeQuery(query);
            while (resultSet.next()) {
                user = new User();
                user.setId(resultSet.getInt("id"));
                user.setFirstName(resultSet.getString("firstname"));
                user.setLastName(resultSet.getString("lastname"));
                user.setCreditCard(resultSet.getString("creditcard"));
                user.setEmail(resultSet.getString("email"));
                user.setAddress(resultSet.getString("address"));
                user.setPhoneNo(resultSet.getString("phoneno"));
                user.setRole(resultSet.getString("role"));
                user.setUserName(resultSet.getString("username"));
                user.setPassword(resultSet.getString("password"));
            }
        } catch (Exception e) {
            return user;
        }
        return user;
    }

}
