package com.repository;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MySQL {

    private final String source;
    private static Connection connection = null;
    public MySQL(String source) {
        this.source = source;
    }

    public Connection getConnection()
            throws ClassNotFoundException, SQLException {
    	if(connection == null) {
    		Class.forName("com.mysql.cj.jdbc.Driver");
    		this.connection = DriverManager.getConnection(source);
    	}
        
        return this.connection;
    }
    
    public ResultSet executeQuery(String query)
            throws SQLException, ClassNotFoundException {
        return getConnection().createStatement().executeQuery(query);
    }

    public Object executeSQL(String sql)
            throws SQLException, ClassNotFoundException {
        return getConnection().createStatement().execute(sql);
    }

    public void closeConnection() {
    	if(connection != null) {
    		try {
				connection.close();
			} catch (SQLException e) {
			}
    	}
    }
}
