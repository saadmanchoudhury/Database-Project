package com.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;


public class Quote implements Serializable {

    private static final long serialVersionUID = 1L;
    private int id;
    private int contractorid;
    private int clientid;
    private String clientName;
    private double price;
    private int size;
    private int height;
    private double distance;
    private Timestamp schedulestart;
    private Timestamp scheduleend;
    private String qstatus;
    private String note;
    private Timestamp msgtime;
    private String pic1;
    private String pic2;
    private String pic3;

    public Quote() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    
	public String getClientName() {
		return clientName;
	}

	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	public int getContractorid() {
		return contractorid;
	}

	public void setContractorid(int contractorid) {
		this.contractorid = contractorid;
	}

	public int getClientid() {
		return clientid;
	}

	public void setClientid(int clientid) {
		this.clientid = clientid;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public double getDistance() {
		return distance;
	}

	public void setDistance(double distance) {
		this.distance = distance;
	}

	public Date getSchedulestart() {
		return schedulestart;
	}

	public void setSchedulestart(Timestamp schedulestart) {
		this.schedulestart = schedulestart;
	}

	public Date getScheduleend() {
		return scheduleend;
	}

	public void setScheduleend(Timestamp scheduleend) {
		this.scheduleend = scheduleend;
	}

	public String getQstatus() {
		return qstatus;
	}

	public void setQstatus(String qstatus) {
		this.qstatus = qstatus;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public Date getMsgtime() {
		return msgtime;
	}

	public void setMsgtime(Timestamp msgtime) {
		this.msgtime = msgtime;
	}

	public String getPic1() {
		return pic1;
	}

	public void setPic1(String pic1) {
		this.pic1 = pic1;
	}

	public String getPic2() {
		return pic2;
	}

	public void setPic2(String pic2) {
		this.pic2 = pic2;
	}

	public String getPic3() {
		return pic3;
	}

	public void setPic3(String pic3) {
		this.pic3 = pic3;
	}

    

}
