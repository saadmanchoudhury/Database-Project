package com.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Map;

public class Client implements Serializable {

    private static final long serialVersionUID = 1L;
    private int id;
    private String firstName;
    private String lastName;
    private int nooftreescut;
    private double dueamount;
    private double paidamount;
    private Map<Integer, Date> treecutmap;
    
    public Client() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    
	public int getNooftreescut() {
		return nooftreescut;
	}

	public void setNooftreescut(int nooftreescut) {
		this.nooftreescut = nooftreescut;
	}

	public double getDueamount() {
		return dueamount;
	}

	public void setDueamount(double dueamount) {
		this.dueamount = dueamount;
	}

	public double getPaidamount() {
		return paidamount;
	}

	public void setPaidamount(double paidamount) {
		this.paidamount = paidamount;
	}

	public Map<Integer, Date> getTreecutmap() {
		return treecutmap;
	}

	public void setTreecutmap(Map<Integer, Date> treecutmap) {
		this.treecutmap = treecutmap;
	}

	@Override
    public String toString() {
        return firstName + " " + lastName;
    }

}
