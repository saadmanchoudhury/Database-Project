package com.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;


public class Bill implements Serializable {

    private static final long serialVersionUID = 1L;
    private int billid;
    private int orderid;
    private int userid;
    private double price;
    private double discount;
    private double balance;
    private String status;
    private Timestamp msgtime;
    private String note;
    
    public Bill() {
    	
    }

	public int getBillid() {
		return billid;
	}

	public void setBillid(int billid) {
		this.billid = billid;
	}

	public int getOrderid() {
		return orderid;
	}

	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Timestamp getMsgtime() {
		return msgtime;
	}

	public void setMsgtime(Timestamp msgtime) {
		this.msgtime = msgtime;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

    
}
