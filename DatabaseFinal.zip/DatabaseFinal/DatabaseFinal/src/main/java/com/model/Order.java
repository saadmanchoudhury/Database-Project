package com.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;


public class Order implements Serializable {

    private static final long serialVersionUID = 1L;
    private int id;
    private int quoteid;
    private double price;
    private Timestamp schedulestart;
    private Timestamp scheduleend;
    private String status;
    
    public Order() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

	public int getQuoteid() {
		return quoteid;
	}

	public void setQuoteid(int quoteid) {
		this.quoteid = quoteid;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public Timestamp getSchedulestart() {
		return schedulestart;
	}

	public void setSchedulestart(Timestamp schedulestart) {
		this.schedulestart = schedulestart;
	}

	public Timestamp getScheduleend() {
		return scheduleend;
	}

	public void setScheduleend(Timestamp scheduleend) {
		this.scheduleend = scheduleend;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

    
	
    

}
