import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class userDAO {
    private Connection connect = null;
    private Statement statement = null;
    private PreparedStatement preparedStatement = null;
    private ResultSet resultSet = null;

    public userDAO() {}

    // Add the Client class
    public class Client {
        private int id;
        private String firstName;
        private String lastName;
        private String address;
        private String creditCard;
        private String phoneNumber;
        private String email;

        // Constructors
        public Client() {}

        public Client(String firstName, String lastName, String address, String creditCard, String phoneNumber, String email) {
            this.firstName = firstName;
            this.lastName = lastName;
            this.address = address;
            this.creditCard = creditCard;
            this.phoneNumber = phoneNumber;
            this.email = email;
        }

        // Getter and setters
        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getFirstName() {
            return firstName;
        }

        public void setFirstName(String firstName) {
            this.firstName = firstName;
        }

        public String getLastName() {
            return lastName;
        }

        public void setLastName(String lastName) {
            this.lastName = lastName;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getCreditCard() {
            return creditCard;
        }

        public void setCreditCard(String creditCard) {
            this.creditCard = creditCard;
        }

        public String getPhoneNumber() {
            return phoneNumber;
        }

        public void setPhoneNumber(String phoneNumber) {
            this.phoneNumber = phoneNumber;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        // Additional methods or fields as needed
    }

    // Add the TreeRequest class
    public class TreeRequest {
        private int id;
        private int clientId;
        private List<String> pictures;
        private String size;
        private String height;
        private String location;
        private boolean nearHouse;
        private String note;
        private String responseNote;
        private double initialPrice;
        private String timeWindow;
        private boolean accepted;

        // Constructors
        public TreeRequest() {
            this.pictures = new ArrayList<>();
        }

        public TreeRequest(int clientId, List<String> pictures, String size, String height, String location, boolean nearHouse, String note, String responseNote, double initialPrice, String timeWindow, boolean accepted) {
            this.clientId = clientId;
            this.pictures = pictures;
            this.size = size;
            this.height = height;
            this.location = location;
            this.nearHouse = nearHouse;
            this.note = note;
            this.responseNote = responseNote;
            this.initialPrice = initialPrice;
            this.timeWindow = timeWindow;
            this.accepted = accepted;
        }

        // Getter and setters
        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getClientId() {
            return clientId;
        }

        public void setClientId(int clientId) {
            this.clientId = clientId;
        }

        public List<String> getPictures() {
            return pictures;
        }

        public void setPictures(List<String> pictures) {
            this.pictures = pictures;
        }

        public String getSize() {
            return size;
        }

        public void setSize(String size) {
            this.size = size;
        }

        public String getHeight() {
            return height;
        }

        public void setHeight(String height) {
            this.height = height;
        }

        public String getLocation() {
            return location;
        }

        public void setLocation(String location) {
            this.location = location;
        }

        public boolean isNearHouse() {
            return nearHouse;
        }

        public void setNearHouse(boolean nearHouse) {
            this.nearHouse = nearHouse;
        }

        public String getNote() {
            return note;
        }

        public void setNote(String note) {
            this.note = note;
        }

        public String getResponseNote() {
            return responseNote;
        }

        public void setResponseNote(String responseNote) {
            this.responseNote = responseNote;
        }

        public double getInitialPrice() {
            return initialPrice;
        }

        public void setInitialPrice(double initialPrice) {
            this.initialPrice = initialPrice;
        }

        public String getTimeWindow() {
            return timeWindow;
        }

        public void setTimeWindow(String timeWindow) {
            this.timeWindow = timeWindow;
        }

        public boolean isAccepted() {
            return accepted;
        }

        public void setAccepted(boolean accepted) {
            this.accepted = accepted;
        }

        // Additional methods or fields as needed
    }

    // Add the OrderOfWork class
    public class OrderOfWork {
        private int id;
        private int treeRequestId;
        private String completionDate;
        private double finalPrice;
        private boolean paymentReceived;

        // Constructors
        public OrderOfWork() {}

        public OrderOfWork(int treeRequestId, String completionDate, double finalPrice, boolean paymentReceived) {
            this.treeRequestId = treeRequestId;
            this.completionDate = completionDate;
            this.finalPrice = finalPrice;
            this.paymentReceived = paymentReceived;
        }

        // Getter and setters
        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public int getTreeRequestId() {
            return treeRequestId;
        }

        public void setTreeRequestId(int treeRequestId) {
            this.treeRequestId = treeRequestId;
        }

        public String getCompletionDate() {
            return completionDate;
        }

        public void setCompletionDate(String completionDate) {
            this.completionDate = completionDate;
        }

        public double getFinalPrice() {
            return finalPrice;
        }

        public void setFinalPrice(double finalPrice) {
            this.finalPrice = finalPrice;
        }

        public boolean isPaymentReceived() {
            return paymentReceived;
        }

        public void setPaymentReceived(boolean paymentReceived) {
            this.paymentReceived = paymentReceived;
        }

        // Additional methods or fields as needed
    }

    // Add the Bill class
    public class Bill {
        private int billId;
        private int orderId;
        private double totalAmount;
        private String status;
        private String clientNote;
        private String smithNote;

        // Constructors
        public Bill() {}

        public Bill(int orderId, double totalAmount) {
            this.orderId = orderId;
            this.totalAmount = totalAmount;
            this.status = "Pending"; // Default status
        }

        // Getter and setters
        public int getBillId() {
            return billId;
        }

        public void setBillId(int billId) {
            this.billId = billId;
        }

        public int getOrderId() {
            return orderId;
        }
           
            public void setOrderId(int orderId) {
                this.orderId = orderId;
            }

            public double getTotalAmount() {
                return totalAmount;
            }

            public void setTotalAmount(double totalAmount) {
                this.totalAmount = totalAmount;
            }

            public String getStatus() {
                return status;
            }

            public void setStatus(String status) {
                this.status = status;
            }

            public String getClientNote() {
                return clientNote;
            }

            public void setClientNote(String clientNote) {
                this.clientNote = clientNote;
            }

            public String getSmithNote() {
                return smithNote;
            }

            public void setSmithNote(String smithNote) {
                this.smithNote = smithNote;
            }

            // Additional methods or fields as needed
        }

        // Add the init method with sample data
        public void init() throws SQLException, FileNotFoundException, IOException {
            connect_func();
            statement = connect.createStatement();

            // Create OrderOfWork table
            String createOrderOfWorkTable = "CREATE TABLE IF NOT EXISTS OrderOfWork(" +
                    "id INT AUTO_INCREMENT PRIMARY KEY," +
                    "treeRequestId INT NOT NULL," +
                    "completionDate VARCHAR(50) NOT NULL," +
                    "finalPrice DECIMAL(13,2) NOT NULL," +
                    "paymentReceived BOOLEAN NOT NULL" +
                    ")";
            statement.execute(createOrderOfWorkTable);

            // Insert sample data into OrderOfWork table
            String insertOrderOfWorkData = "INSERT INTO OrderOfWork(treeRequestId, completionDate, finalPrice, paymentReceived) VALUES " +
                    "(1, '2023-01-15', 500.00, true)," +
                    "(2, '2023-02-01', 750.00, false)";
            statement.execute(insertOrderOfWorkData);

            // Create Client table
            String createClientTable = "CREATE TABLE IF NOT EXISTS Client(" +
                    "id INT AUTO_INCREMENT PRIMARY KEY," +
                    "firstName VARCHAR(50) NOT NULL," +
                    "lastName VARCHAR(50) NOT NULL," +
                    "address VARCHAR(100) NOT NULL," +
                    "creditCard VARCHAR(16) NOT NULL," +
                    "phoneNumber VARCHAR(15) NOT NULL," +
                    "email VARCHAR(50) NOT NULL UNIQUE" +
                    ")";
            statement.execute(createClientTable);

            // Insert sample data into Client table
            String insertClientData = "INSERT INTO Client(firstName, lastName, address, creditCard, phoneNumber, email) VALUES " +
                    "('John', 'Doe', '123 Main St', '1234567890123456', '555-1234', 'john@example.com')," +
                    "('Jane', 'Smith', '456 Oak St', '9876543210987654', '555-5678', 'jane@example.com')";
            statement.execute(insertClientData);

            // Create TreeRequest table
            String createTreeRequestTable = "CREATE TABLE IF NOT EXISTS TreeRequest(" +
                    "id INT AUTO_INCREMENT PRIMARY KEY," +
                    "clientId INT NOT NULL," +
                    "pictures TEXT," +
                    "size VARCHAR(50) NOT NULL," +
                    "height VARCHAR(50) NOT NULL," +
                    "location VARCHAR(100) NOT NULL," +
                    "nearHouse BOOLEAN NOT NULL," +
                    "note TEXT," +
                    "responseNote TEXT," +
                    "initialPrice DECIMAL(13,2)," +
                    "timeWindow VARCHAR(50)," +
                    "accepted BOOLEAN" +
                    ")";
            statement.execute(createTreeRequestTable);

            // Insert 10 random data into TreeRequest table
            Random random = new Random();
            for (int i = 0; i < 10; i++) {
                String pictures = "pic" + (i + 1) + ".jpg";
                int clientId = random.nextBoolean() ? 1 : 2;
                String size = random.nextBoolean() ? "Large" : "Medium";
                String height = random.nextBoolean() ? "10 ft" : "8 ft";
                String location = random.nextBoolean() ? "Front yard" : "Backyard";
                boolean nearHouse = random.nextBoolean();
                String note = "Random note " + (i + 1);
                String responseNote = "Random response " + (i + 1);
                double initialPrice = 100.00 + random.nextDouble() * 900.00;
                String timeWindow = "2023-01-10 to 2023-01-15";
                boolean accepted = random.nextBoolean();

                String insertTreeRequestData = "INSERT INTO TreeRequest(clientId, pictures, size, height, location, nearHouse, note, responseNote, initialPrice, timeWindow, accepted) VALUES " +
                        "(" + clientId + ", '" + pictures + "', '" + size + "', '" + height + "', '" + location + "', " + nearHouse + ", '" + note + "', '" + responseNote + "', " + initialPrice + ", '" + timeWindow + "', " + accepted + ")";
                statement.execute(insertTreeRequestData);
            }

            // Create Bill table
            String createBillTable = "CREATE TABLE IF NOT EXISTS Bill(" +
                    "id INT AUTO_INCREMENT PRIMARY KEY," +
                    "orderId INT NOT NULL," +
                    "totalAmount DECIMAL(13,2) NOT NULL," +
                    "status VARCHAR(20) NOT NULL," +
                    "clientNote TEXT," +
                    "smithNote TEXT" +
                    ")";
            statement.execute(createBillTable);

            // Insert 10 random data into Bill table
            for (int i = 0; i < 10; i++) {
                int orderId = i + 1;
                double totalAmount = 100.00 + random.nextDouble() * 900.00;
                String status = random.nextBoolean() ? "Pending" : "Paid";
                String clientNote = "Client note " + (i + 1);
                String smithNote = "Smith note " + (i + 1);

                String insertBillData = "INSERT INTO Bill(orderId, totalAmount, status, clientNote, smithNote) VALUES " +
                        "(" + orderId + ", " + totalAmount + ", '" + status + "', '" + clientNote + "', '" + smithNote + "')";
                statement.execute(insertBillData);
            }
            }

            public void insertTreeRequest(TreeRequest treeRequest) throws SQLException {
                connect_func();

                // Insert sample data into TreeRequest table
                String insertTreeRequestData = "INSERT INTO TreeRequest(clientId, pictures, size, height, location, nearHouse, note, responseNote, initialPrice, timeWindow, accepted) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                preparedStatement = connect.prepareStatement(insertTreeRequestData);
                preparedStatement.setInt(1, treeRequest.getClientId());
                preparedStatement.setString(2, String.join(",", treeRequest.getPictures()));
                preparedStatement.setString(3, treeRequest.getSize());
                preparedStatement.setString(4, treeRequest.getHeight());
                preparedStatement.setString(5, treeRequest.getLocation());
                preparedStatement.setBoolean(6, treeRequest.isNearHouse());
                preparedStatement.setString(7, treeRequest.getNote());
                preparedStatement.setString(8, treeRequest.getResponseNote());
                preparedStatement.setDouble(9, treeRequest.getInitialPrice());
                preparedStatement.setString(10, treeRequest.getTimeWindow());
                preparedStatement.setBoolean(11, treeRequest.isAccepted());

                preparedStatement.executeUpdate();
            }


        // Add the connect_func method
        protected void connect_func() throws SQLException {
       
        	
            // Uses default connection to the database
            if (connect == null || connect.isClosed()) {
                try {
                    Class.forName("com.mysql.cj.jdbc.Driver");
                } catch (ClassNotFoundException e) {
                    throw new SQLException(e);
                }
                connect = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/testdb?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC&allowPublicKeyRetrieval=true&useSSL=false&user=john&password=john1234");
                System.out.println(connect);
            }
        }

		public List<user> listAllUsers() {
			// TODO Auto-generated method stub
			return null;
		}

		public boolean isValid(String email, String password) {
			// TODO Auto-generated method stub
			return false;
		}

		public boolean checkEmail(String email) {
			// TODO Auto-generated method stub
			return false;
		}

		public void insert(user users) {
			// TODO Auto-generated method stub
			
		}


    }
