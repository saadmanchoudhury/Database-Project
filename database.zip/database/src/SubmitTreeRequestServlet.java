import java.io.IOException;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/SubmitTreeRequestServlet")
public class SubmitTreeRequestServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve form parameters
        int clientId = Integer.parseInt(request.getParameter("clientId")); // Adjust as needed
        List<String> pictures = Arrays.asList(request.getParameter("pictures").split(",")); // Adjust as needed
        String size = request.getParameter("size");
        String height = request.getParameter("height");
        String location = request.getParameter("location");
        boolean nearHouse = Boolean.parseBoolean(request.getParameter("nearHouse"));
        String note = request.getParameter("note");
        String responseNote = request.getParameter("responseNote");
        double initialPrice = Double.parseDouble(request.getParameter("initialPrice"));
        String timeWindow = request.getParameter("timeWindow");
        boolean accepted = Boolean.parseBoolean(request.getParameter("accepted"));

        // Create a TreeRequest object with the form data
        userDAO.TreeRequest treeRequest = new userDAO().new TreeRequest(
                clientId, pictures, size, height, location, nearHouse, note, responseNote, initialPrice, timeWindow, accepted);

        // Initialize the DAO and insert the tree service request
        userDAO dao = new userDAO();
        try {
            dao.init(); // Make sure the database tables are created (you may want to call this method only once in your application)

            dao.insertTreeRequest(treeRequest);

            // Redirect to a success page or display a success message
            response.sendRedirect("success.jsp"); 
        } catch (SQLException e) {
            e.printStackTrace(); 
        }
    }
}
