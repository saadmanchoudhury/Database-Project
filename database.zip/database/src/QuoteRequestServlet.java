import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/submitQuoteRequest")

public class QuoteRequestServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form data
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String address = request.getParameter("address");
        String creditCard = request.getParameter("creditCard");
        String phoneNumber = request.getParameter("phoneNumber");
        String email = request.getParameter("email");
        
        // Create a Client object and populate it
        Client client = new Client();
        client.setFirstName(firstName);
        client.setLastName(lastName);
        client.setAddress(address);
        client.setCreditCard(creditCard);
        client.setPhoneNumber(phoneNumber);
        client.setEmail(email);

        // Process the data (insert into the database, etc.)

        // Redirect to a confirmation page or another relevant page
        response.sendRedirect("confirmation.jsp");
    }
}
